# Proyecto

Sistema integral de gestión académica universitaria

## Dependencias

- tkinter (para interfaces gráficas)  
- Pillow (para manejo de imágenes)
